<table class="table table-bordered table-comment">
    <tr>
        <th class="text-center text-warning table-comment title"> <?= $comment['title'] ?></th>
    </tr>
    <tr>
        <th class="text-center table-content table-content-comment">
            <?= $comment['data'] ?>
        </th>
    </tr>
    <tr>
        <th class=""><div class="text-left col-md-6 table-comment-author"><?= $comment['username'] ?></div><div class="col-md-6 text-right table-comment-date"><?= $comment['dt']; ?></div></th>
    </tr>
</table>