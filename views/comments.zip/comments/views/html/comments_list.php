<tr>
    <td><?= $row['id']?></td>
    <td><?= $row['email']; ?></td>
    <td><?= $row['title']?></td>
    <td><?= $row['dt']?></td>
    <td >
        <center>
            <a id="edit-comment" href="<?php echo $base_url?>/comment_edit?ID=<?php echo $row['id']?>&page=<?php echo $page?>">
                <i class="fa fa-pencil"></i>
            </a>
            <a class="text-success" id="view-comment" href="<?php echo $base_url?>/view_comment?ID=<?php echo $row['id']?>&page=<?php echo $page?>">
                <i class="fa fa-eye"></i>
            </a>
            <a <?= $row['moderated'] == '1' ? "class=\"text-danger\"" : "class=\"text-success\"" ?> id="public_comment" href="<?php echo $base_url?>/public_comment?ID=<?php echo $row['id']?>&page=<?php echo $page?>">
                <i class="fa fa-adjust" ></i>
            </a>
            <a class="text-danger" id="del_user" href="<?php echo $base_url?>/comment_delete?ID=<?php echo $row['id']?>&page=<?php echo $page?>">
                <i class=" fa fa-trash-o"></i>
            </a>
        </center>
    </td>
    <td><?= $row['moderated'] == 1 ? "Yes" : "No" ?></td>
</tr>
