<script type="text/javascript">
    function sendComment(address, id){
        var title = jQuery("#comment_title").attr("value");
        var data = jQuery("#comment_data").attr("value");
        var messageBlock = jQuery("#comment-message-error");
        jQuery.post(address, {comment_data : data, comment_title : title, ID : id}, function(data){
            if(data.length > 0){
                messageBlock.html(data);
                    if(messageBlock.attr('display') != 'none') {
                        messageBlock.slideDown(400);
                    }
                messageBlock.delay(5000);
                messageBlock.slideUp(400);
            }
        });
    }
</script>
<form class="form-horizontal comment-form" method="post">
    <fieldset>
        <legend>Edit comment</legend>

        <div id="comment-message-error" class="comment-message-error"></div>
        <div class="form-group" id="comment-form-head">
            <label class="col-md-3 control-label" for="comment_title">Title</label>
            <div class="col-md-8">
                <input id="comment_title" name="comment_title" class="form-control input-md" type="text" value="<?= isset($title) ? $title : '' ?>">
            </div>
        </div>

        <div class="form-group" id="comment-form-data">
            <label class="col-md-3 control-label" for="comment_data">Comment text</label>
            <div class="col-md-8">
                <textarea class="form-control" id="comment_data" name="comment_data"><?= isset($data) ? $data : "" ?></textarea>
            </div>
        </div>

        <div class="form-group" id="comment-form-save">
            <label class="col-md-3 control-label" for="add-form-send"></label>
            <div class="col-md-8">
                <center><a id="add-form-send" name="comment-send-button" class="comment-button btn" onclick='sendComment("<?php echo (BASE_URL . '/comment_update_save'); ?>", "<?= $_GET['ID'] ?>")'>Save</a></center>
            </div>
        </div>

    </fieldset>
</form>

