<div class="comment-data-view">
    <?= $content ?>
</div>