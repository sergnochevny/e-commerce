<div class="alert-danger text-center comment-message-error">
    <?php
        foreach ($errs as $e){
            echo "{$e}<br />";
        }
    ?>
</div>