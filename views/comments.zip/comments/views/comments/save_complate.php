<div id="comment-message-error-success" class="main-content-inner text-center" role="main">
    <p class="alert-success">Thank you. You comment sent for moderation.<br />. <a href='<?php echo $main_page; ?>'>Main Page</a><br /> 
        <a href='<?php echo $comments_page; ?>'>Comments page</a>.</p>
</div>

