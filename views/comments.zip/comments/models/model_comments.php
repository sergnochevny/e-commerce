<?php
	class Model_Comments{
		static private $_instance = null;
		
		private function __clone(){}
		private function __construct(){}
		public static function getInstance(){
			if(is_null(self::$_instance)){
				self::$_instance = new self();
			}
			return self::$_instance;
		}
		public function get($ID){
			$query = sprintf("select * from fabrix_comments where ID = %d", $ID);
			$res = mysql_query($query);
			if(!$res){ return null; }
			$data = mysql_fetch_array($res);
			
			return $data;
		}
		public function add($comment){
			$query = sprintf("insert into fabrix_comments values(NULL, '%s', '%s', CURRENT_TIMESTAMP, %d, %d)", 
			$comment->getTitle(), $comment->getData(), $comment->getUserID(), $comment->getModerated());
			$res = mysql_query($query);
			if(!$res){ return false; }
			
			return true;
		}
		public function delete($ID){ //Tested!
			$query = sprintf("delete from fabrix_comments where `id` = %d", $ID);
			$res = mysql_query($query);
			if(!$res){ return false; }
			
			return true;
		}
		public function update($comment){
			$query = sprintf("update fabrix_comments set `title`='%s', data='%s', `dt`='{$comment->getDate()}', `userid`='%d', `moderated`='%d' where ID = %d",
			$comment->getTitle(), $comment->getData(), $comment->getUserID(), $comment->getModerated(), $comment->getID());
                        
			$res = mysql_query($query);
			if(!$res){ return false; }
			
			return true;
		}
        public function getAll($begin = -1, $count = -1, $moderated = -1){

                    $query = "select * from fabrix_comments";
                    if($moderated > -1){
                        $query .= sprintf(" where `moderated` = %d", $moderated);
                    }
                    if($begin > -1 && $count > -1){
                        $query .= sprintf(" LIMIT %d, %d", $begin, $count);
                    }
                    $res = mysql_query($query);
                    if(!res){ return null; }
                    
                    $data = array();
                    for($i = 0; $row = mysql_fetch_assoc($res); $i++){
                        $name = $this->getUserName($row['userid']);
                            
                        if(!empty($name)){ 
                            $row['username'] = $this->getUserName($row['userid']);
                        }
                        $data[$i] = $row;
                    }
                    
                    return $data;
                }
        public function getUserName($ID){
                    $query = sprintf("select bill_firstname, bill_lastname from fabrix_accounts where aid = %d", $ID);
                    $res = mysql_query($query);
                    
                    if(!res){ return false; }
                    
                    $data = mysql_fetch_assoc($res);
                    if(empty($data)) return "Unknown user";
                    
                    return $data['bill_firstname'] . " " . $data['bill_lastname'];
                }
        public function getUserEmail($ID){
                    $query = sprintf("select `email` from fabrix_accounts where aid = %d", $ID);
                    $res = mysql_query($query);
                    if(!res){ return false; }
                    
                    $data = mysql_fetch_assoc($res);
                    
                    return $data['email'];
                }
        public function getTotalCountComments($moderated = -1){
                    $total = 0;
                    $query = "SELECT COUNT(*) FROM `fabrix_comments`";
                    if($moderated > -1)
                        $query .= sprintf(" WHERE `moderated` = %d", $moderated);

                    if ($res = mysql_query($query)) {
                        $total = mysql_fetch_row($res)[0];
                    }
                    return $total;
                }
                
	}